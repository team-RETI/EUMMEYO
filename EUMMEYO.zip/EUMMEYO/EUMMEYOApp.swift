//
//  EUMMEYOApp.swift
//  EUMMEYO
//
//  Created by 김동현 on 11/19/24.
//

import SwiftUI

@main
struct EUMMEYOApp: App {
    var body: some Scene {
        WindowGroup {
            MaintabView()
        }
    }
}
