//
//  ContentView.swift
//  EUMMEYO
//
//  Created by 김동현 on 11/19/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Content View")
        }
    }
}

#Preview {
    ContentView()
}
